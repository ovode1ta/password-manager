this is a basic python project I decided to make

wow you read the readme.txt file